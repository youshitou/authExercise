/**
 * 
 */
package com.exercise.access.entity;

import java.util.ArrayList;

/**
 * role entity
 * @author Jeff Shi
 *
 */

public class Role {
	private String roleName;
	
	private String roleDesc;

	private ArrayList <User> userList; 
	
	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public ArrayList<User> getUserList() {
		return userList;
	}

	public void setUserList(ArrayList<User> userList) {
		this.userList = userList;
	}

}
