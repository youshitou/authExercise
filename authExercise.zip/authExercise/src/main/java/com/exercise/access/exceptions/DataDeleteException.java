package com.exercise.access.exceptions;

/**
 * Throw this exception when error occupies to delete an entity
 * @author Jeff Shi
 */
public class DataDeleteException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 3493628258788074273L;

	public DataDeleteException(String message) {
        super(message);
    }
}
