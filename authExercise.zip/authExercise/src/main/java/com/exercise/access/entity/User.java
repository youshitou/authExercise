/**
 * 
 */
package com.exercise.access.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * User entity
 * @author Jeff Shi
 *
 */

public class User {
	private String userName;

	private String password;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@JsonIgnore
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
