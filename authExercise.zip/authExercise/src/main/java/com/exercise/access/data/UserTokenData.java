package com.exercise.access.data;

import java.time.LocalDateTime;
import java.util.*;

import com.exercise.access.encrypt.Encrypt;
import com.exercise.access.entity.*;
import com.exercise.access.exceptions.DataNotExistException;

/**
 * handle token activities
 * @author Jeff Shi
 */
public class UserTokenData {

	//Map to save use token data, key is token
	private static final Map<String, TokenUser> tokenMap = new HashMap<>();
	
	//Expired time
    private static final int expireSecond = 7200;

    //Remove a token from token map
    public static void removeEntry(String userName) {
        //Remove tokenUser from tokenMap
        for (Map.Entry<String, TokenUser> entry : tokenMap.entrySet()) {
            if (entry.getValue().getUserName().equals(userName)) {
            	tokenMap.remove(entry.getKey());
            }
        }
    }

    //invalidate a token, return exception when token is invalid
    public static void invalidate(String id) {
    	if(tokenMap.containsKey(id)) {
        	tokenMap.remove(id);
    	} else {
    		throw new DataNotExistException("Token is invalid.");
    	}

    }
    
    //search TokenUser by token, remove token if it's expired
    public static TokenUser queryToken(String token) {
    	TokenUser tokenUser = tokenMap.get(token);
    	if ((tokenUser != null) && tokenUser.getExpiredDate().isBefore(LocalDateTime.now())) {
    		tokenMap.remove(token);
    		tokenUser = null;
    	}
        return tokenUser;
    }
    
    /*authenticate a new token, if the token is existing, renew the expired date
     *key is token, value is TokenUser which includes user name, expired date and role list
     */
    public static TokenUser authenticate(String userName, String password, int newExpireSecond) {
        User user = UserData.query(userName);
        String token = "";
    	if ((user != null) && (user.getPassword().equals(Encrypt.encrypt(password)))) {
    		token = UUID.randomUUID().toString();
    	} else {
            throw new DataNotExistException("User does not exist or password is wrong.");
    	}
    	if (newExpireSecond == 0) {
    		newExpireSecond = expireSecond;
    	}
    	LocalDateTime expiredDate = LocalDateTime.now().plusSeconds(newExpireSecond);
    	TokenUser tokenUser = queryToken(token);
    	if (tokenUser != null) {
    		tokenUser.setExpiredDate(expiredDate);
    	} else {
        	tokenUser = new TokenUser();
        	tokenUser.setUserName(userName);
    		tokenUser.setExpiredDate(expiredDate);
    		tokenUser.setToken(token);
        	ArrayList<String> tokenRoleList = new ArrayList<String>();
            List<Role> roleList = RoleData.queryAll();
            for (Role role: roleList) {
            	ArrayList<User> userList = role.getUserList();
            	if ((userList != null) && (userList.contains(user))) {
            		tokenRoleList.add(role.getRoleName());
            	}
            }
            tokenUser.setRoleList(tokenRoleList);
            tokenMap.put(token, tokenUser);
    	}
        return tokenUser;
    }
    
    //Add role to TokenUser if the user had a token and execute add user to role
    public static void addRoletoTokenMap(String userName, String roleName) {
        for (Map.Entry<String, TokenUser> entry : tokenMap.entrySet()) {
            if (entry.getValue().getUserName().equals(userName)) {
            	entry.getValue().getRoleList().add(roleName);
            }
        }
    }
    
    //remove roles from TokenUser if the user had a token and execute role deletion
    public static void removeRolefromTokenMap(Role role) {
    	if (role != null) {
        	String roleName = role.getRoleName();
        	ArrayList<User> userList = role.getUserList();
        	if (userList != null) {
            	for (User user : role.getUserList()) {
            		String userName = user.getUserName();
            		removeRolefromTokenMap(userName, roleName);
            	}
        	}
    	}
    }
    
    //remove role from TokenUser if the user had a token and execute remove user from role
    public static void removeRolefromTokenMap(String userName, String roleName) {
        for (Map.Entry<String, TokenUser> entry : tokenMap.entrySet()) {
            if (entry.getValue().getUserName().equals(userName)) {
            	entry.getValue().getRoleList().remove(roleName);
            }
        }
    }
    
    /*check user belongs a role by token and role. Return true if belong, else false
     * throw exception if role or token is not existing 
     */
    public static boolean checkRole(String token, Role role) {
    	
    	TokenUser tokenUser = queryToken(token);
    	if(tokenUser != null) {
    		if (role == null) {
    			throw new DataNotExistException("Role does not exist.");
    		}
            if (tokenUser.getRoleList().contains(role.getRoleName())) {
            	return true;
            } else {
            	return false;
            }
    	} else {
    		throw new DataNotExistException("Token is invalid.");
    	}    	
    }

    /*return all roles which user belonged by token
     * throw exception if token is not existing
     */
    public static ArrayList<String> retrieveAllRoles(String token) {
    	ArrayList<String> roleList;
    	TokenUser tokenUser = queryToken(token);
    	if(tokenUser != null) {
        	roleList=tokenUser.getRoleList();
    	} else {
    		throw new DataNotExistException("Token is invalid.");
    	}
    	return roleList;
    }

    //Remove all tokens
    public static void clean() {
    	tokenMap.clear();
    }
    
}
