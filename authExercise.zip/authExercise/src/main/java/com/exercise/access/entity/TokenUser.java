/**
 * 
 */
package com.exercise.access.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 * TokenUser entity
 * @author Jeff Shi
 *
 */

public class TokenUser {
	private String userName;

	private ArrayList <String> roleList; 
	
	private LocalDateTime expiredDate;
	
	private String token;
	
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public ArrayList<String> getRoleList() {
		return roleList;
	}

	public void setRoleList(ArrayList<String> roleList) {
		this.roleList = roleList;
	}
	
	public LocalDateTime getExpiredDate() {
		return expiredDate;
	}

	public void setExpiredDate(LocalDateTime expiredDate) {
		this.expiredDate = expiredDate;
	}

}
