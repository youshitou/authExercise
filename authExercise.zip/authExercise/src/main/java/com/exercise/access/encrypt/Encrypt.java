package com.exercise.access.encrypt;

import java.math.BigInteger;
import java.security.MessageDigest;

/**
 * Encrypt password
 * @author Jeff Shi
 */

public class Encrypt {

	public static final String KEY_SHA = "SHA";

	public static String encrypt(String inputStr) {
		BigInteger sha = null;
		byte[] inputData = inputStr.getBytes();
		try {
			MessageDigest messageDigest = MessageDigest.getInstance(KEY_SHA);
			messageDigest.update(inputData);
			sha = new BigInteger(messageDigest.digest());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sha.toString();
	}

}
