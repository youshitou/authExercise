/**
 * 
 */
package com.exercise.access.entity;

/**
 * RequestBody when create role  
 * @author Jeff Shi
 *
 */

public class ReqRole {
	private String roleName;
	
	private String roleDesc;

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

}
