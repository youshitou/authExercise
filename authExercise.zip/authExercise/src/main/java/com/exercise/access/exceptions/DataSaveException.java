package com.exercise.access.exceptions;

/**
 * Throw this exception when error occupies to create an entity
 * @author Jeff Shi
 */
public class DataSaveException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 6969375538926209574L;

	public DataSaveException() {
    }

    public DataSaveException(String message) {
        super(message);
    }
}
