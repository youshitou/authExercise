/**
 * 
 */
package com.exercise.access.entity;

/**
 * RequestBody when add/remove user to role 
 * @author Jeff Shi
 *
 */

public class ReqUserRole {
	
	private String userName;

	private String roleName;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

}
