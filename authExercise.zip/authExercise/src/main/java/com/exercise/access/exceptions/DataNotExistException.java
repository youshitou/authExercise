package com.exercise.access.exceptions;

/**
 * Throw this exception when the entity isn't existing.
 * @author Jeff Shi
 */
public class DataNotExistException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 4812061536508366457L;

	public DataNotExistException(String message) {
        super(message);
    }
}
