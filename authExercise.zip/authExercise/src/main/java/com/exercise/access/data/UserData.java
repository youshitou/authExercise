package com.exercise.access.data;

import java.util.*;

import com.exercise.access.entity.*;
import com.exercise.access.exceptions.DataDeleteException;
import com.exercise.access.exceptions.DataSaveException;

/**
 * handle user activities
 * @author Jeff Shi
 */
public class UserData {

	//Map to save role data, key is user name
    private static final Map<String, User> map = new HashMap<>();

    //create a new user
    public static void save(User user) {
        String id = user.getUserName();
        User result = query(id);
        if (Objects.nonNull(result)) {
            throw new DataSaveException("User already Exists, fail to create.");
        }
        map.put(user.getUserName(), user);
    }

    //search user by user name
    public static User query(String id) {
        return map.get(id);
    }

    //return all users
    public static List<User> queryAll() {
        List<User> list = new ArrayList<>();
        for (Map.Entry<String, User> entry : map.entrySet()) {
            list.add(entry.getValue());
        }
        return list;
    }

    //delete a user by user name
    public static void delete(String id) {
        User result = query(id);
        if (result == null) {
            throw new DataDeleteException("User does not exist, fail to delete.");
        }
        //Remove user from role.userList
        List<Role> roleList = RoleData.queryAll();
        if (roleList != null) {
            for (Role role: roleList) {
            	ArrayList<User> userList = role.getUserList();
            	if (userList.contains(result)) {
            		userList.remove(result);
            	}
            }
        }
        
        UserTokenData.removeEntry(id);
        map.remove(id);
    }
    
    //remove all users from map
    public static void clean() {
    	map.clear();
    }

}
