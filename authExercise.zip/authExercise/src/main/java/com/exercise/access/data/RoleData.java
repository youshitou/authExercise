package com.exercise.access.data;

import java.util.*;

import com.exercise.access.entity.*;
import com.exercise.access.exceptions.DataDeleteException;
import com.exercise.access.exceptions.DataNotExistException;
import com.exercise.access.exceptions.DataSaveException;

/**
 * handle role activities
 * @author Jeff Shi
 */
public class RoleData {

    //Map to save role data, key is role name
	private static final Map<String, Role> map = new HashMap<>();

	//Create a new role
    public static void save(Role role) {
        String id = role.getRoleName();
        Role result = query(id);
        if (Objects.nonNull(result)) {
            throw new DataSaveException("Role alreay exists, fail to create.");
        }
        map.put(role.getRoleName(), role);
    }

    //Search role by role name
    public static Role query(String id) {
        return map.get(id);
    }

    //return all roles
    public static List<Role> queryAll() {
        List<Role> list = new ArrayList<>();
        for (Map.Entry<String, Role> entry : map.entrySet()) {
            list.add(entry.getValue());
        }
        return list;
    }

    //delete a role by role name
    public static void delete(String id) {
    	Role result = query(id);
        if (result == null) {
            throw new DataDeleteException("Role does not exist, fail to delete.");
        }
        UserTokenData.removeRolefromTokenMap(result);
        map.remove(id);
    }

    //add user to role
    public static void addUsertoRole(String userName, String roleName) {
    	User user = UserData.query(userName);
    	Role role = RoleData.query(roleName);
    	if (user == null) {
    		throw new DataNotExistException("User '" + userName + "' does not exist.");
    	}  else if (role == null) {
    		throw new DataNotExistException("Role '" + roleName + "' does not exist.");
        } else {
        	ArrayList<User> userList = role.getUserList();
        	if (userList == null) {
        		userList = new ArrayList<User> ();
        	}
        	if (!userList.contains(user)) {
        		userList.add(user);	
        	}
        	role.setUserList(userList);
        	UserTokenData.addRoletoTokenMap(userName,roleName);
    	}
    }
    
  //remove user from role
    public static void removeUserfromRole(String userName, String roleName) {
    	User user = UserData.query(userName);
    	Role role = RoleData.query(roleName);
    	if (user == null) {
    		throw new DataNotExistException("User '" + userName + "' does not exist.");
    	}  else if (role == null) {
    		throw new DataNotExistException("Role '" + roleName + "' does not exist.");
        } else {
        	ArrayList<User> userList = role.getUserList();
        	if ((userList != null) && (userList.contains(user))) {
        		userList.remove(user);	
        	} else {
	    		throw new DataNotExistException("Role '" + roleName + "' is not including user " + userName + ".");
        	}
        	role.setUserList(userList);
        	UserTokenData.removeRolefromTokenMap(userName,roleName);
    	}
    }
    
    //remove all roles from map
    public static void clean() {
    	map.clear();
    }

}
