package com.exercise.access.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.exercise.access.data.RoleData;
import com.exercise.access.data.UserData;
import com.exercise.access.data.UserTokenData;
import com.exercise.access.encrypt.Encrypt;
import com.exercise.access.entity.ReqRole;
import com.exercise.access.entity.ReqUser;
import com.exercise.access.entity.ReqUserRole;
import com.exercise.access.entity.RespEntity;
import com.exercise.access.entity.Role;
import com.exercise.access.entity.TokenUser;
import com.exercise.access.entity.User;
import com.exercise.access.exceptions.DataDeleteException;
import com.exercise.access.exceptions.DataNotExistException;
import com.exercise.access.exceptions.DataSaveException;
/**
 * API interface controller, can be accessed via http://localhost:8080/api
 * Sample: list all users - http://localhost:8080/api/use
 * @author Jeff Shi
 */
@Controller
@RequestMapping(value = "/api")
public class APIController {

    /**
     * List all users
     * @param
     * @return success - user list, fail - error message
     */
    @RequestMapping("/user")
    @ResponseBody
    public RespEntity user() {
    	return new RespEntity(0, "Success", UserData.queryAll());
    }

	/**
     * Create user
     * @param ReqUser - user name and password
     * @return success - user information, fail - error message
     */
    @RequestMapping("/user/create")
    @ResponseBody
    public RespEntity createUser(@RequestBody ReqUser reqUser) {
    	
        String name = reqUser.getUserName();
        String password = reqUser.getPassword();
        User user = new User();
        user.setUserName(name);
        user.setPassword(Encrypt.encrypt(password));
        try {
            UserData.save(user);
        } catch (DataSaveException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success", user);
    }
    
    /**
     * Delete user, will remove token form tokenMap if user has token, and remove user from role
     * @param user name
     * @return success - user information, fail - error message
     */
    @RequestMapping("/user/delete")
    @ResponseBody
    public RespEntity DeleteUser(@RequestParam(value = "userName", defaultValue = "") String userName) {
        try {
            UserData.delete(userName);
        } catch (DataDeleteException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success", "Success to delete user:" + userName);
    }
    
    /**
     * List all roles
     * @param 
     * @return success - role list, fail - error message
     */
    @RequestMapping("/role")
    @ResponseBody
    public RespEntity role() {
    	return new RespEntity(0, "Success", RoleData.queryAll());
    }
    
	/**
     * Create role
     * @param ReqRole - role name and role description
     * @return success - role information, fail - error message
     */
    @RequestMapping("/role/create")
    @ResponseBody
    public RespEntity createRole(@RequestBody ReqRole reqRole) {
    	
        String name = reqRole.getRoleName();
        String desc = reqRole.getRoleDesc();
        Role role = new Role();
        role.setRoleName(name);
        role.setRoleDesc(desc);
        try {
            RoleData.save(role);
        } catch (DataSaveException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success", role);
    }
    
    /**
     * Delete role, will remove role from userToken if user has token
     * @param role name
     * @return success - role information, fail - error message
     */
    @RequestMapping("/role/delete")
    @ResponseBody
    public RespEntity DeleteRole(@RequestParam(value = "roleName", defaultValue = "") String roleName) {
        try {
            RoleData.delete(roleName);
        } catch (DataDeleteException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success", "Success to delete role:" + roleName);
    }

	/**
     * Add user to role, will add role to userToken if user has token
     * @param ReqUserRole - role name and user name
     * @return success - user information, fail - error message
     */
    @RequestMapping("/role/addUsertoRole")
    @ResponseBody
    public RespEntity addUsertoRole(@RequestBody ReqUserRole reqUserRole) {
    	
        String userName = reqUserRole.getUserName();
        String roleName = reqUserRole.getRoleName();
        try {
        	RoleData.addUsertoRole(userName, roleName);
        } catch (DataSaveException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        } catch (DataNotExistException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success", RoleData.query(roleName));
    }

	/**
     * remove user from role
     * @param ReqUserRole - role name and user name
     * @return success - role information, fail - error message
     */
    @RequestMapping("/role/removeUserfromRole")
    @ResponseBody
    public RespEntity removeUserfromRole(@RequestBody ReqUserRole reqUserRole) {
    	
        String userName = reqUserRole.getUserName();
        String roleName = reqUserRole.getRoleName();
        try {
        	RoleData.removeUserfromRole(userName, roleName);
        } catch (DataNotExistException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success", RoleData.query(roleName));
    }

    /**
     * Authenticate, generate or fresh token expired date
     * @param ReqUser - user name and password
     * @return success - token, fail - error message
     */
    @RequestMapping("/userToken/authenticate")
    @ResponseBody
    public RespEntity authenticate(@RequestBody ReqUser reqUser, @RequestParam(value = "expire", defaultValue = "0") String expire) {
    	
        String name = reqUser.getUserName();
        String password = reqUser.getPassword();
        TokenUser tokenUser;
        try {
        	tokenUser = UserTokenData.authenticate(name, password, new Integer(expire).intValue());
        } catch (DataNotExistException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success", tokenUser);
    }
    	
	/**
     * Invalidate the token
     * @param token
     * @return success, fail - error message
     */
    @RequestMapping("/userToken/invalidate")
    @ResponseBody
    public RespEntity invalidate(@RequestParam(value = "token", defaultValue = "") String token) {
        try {
        	UserTokenData.invalidate(token);
        } catch (DataNotExistException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success");
    }

	/**
     * check role by token
     * @param token and role name
     * @return success, fail - error message
     */
    @RequestMapping("/userToken/checkRole")
    @ResponseBody
    public RespEntity checkRole(@RequestParam(value = "token", defaultValue = "") String token, @RequestParam(value = "roleName", defaultValue = "") String roleName) {
        boolean result;
    	try {
        	Role role = RoleData.query(roleName);
        	result = UserTokenData.checkRole(token, role);
        } catch (DataNotExistException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success", result);
    }
    
	/**
     * retrieve all roles by tokens
     * @param token
     * @return success - all role, fail - error message
     */
    @RequestMapping("/userToken/retrieveAllRoles")
    @ResponseBody
    public RespEntity retrieveAllRoles(@RequestParam(value = "token", defaultValue = "") String token) {
    	ArrayList<String> roleList;
    	try {
    		roleList = UserTokenData.retrieveAllRoles(token);
        } catch (DataNotExistException e) {
        	return new RespEntity(-1, "Error", e.getMessage());
        }
        return new RespEntity(0, "Success", roleList);
    }
}
