/*
 */
package com.exercise.access;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.exercise.access.data.RoleData;
import com.exercise.access.data.UserData;
import com.exercise.access.data.UserTokenData;

/**
 * Unit test for all APIs
 * @author Jeff Shi
 */

@SpringBootTest
@AutoConfigureMockMvc
public class APIControllerTests {

	@Autowired
	private MockMvc mockMvc;

	@BeforeEach
	public void deleteAllBeforeTests() throws Exception {
		UserData.clean();
		RoleData.clean();
		UserTokenData.clean();
	}
	
	@Test
	public void successCreateUser() throws Exception {

		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.data.userName").value("Frodo"));
		
		
	}

	// Fail to create if user already exists
	@Test
	public void failCreateUser() throws Exception {

		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));
		
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.msg").value("Error"));
	}

	@Test
	public void retrieveUserList() throws Exception {

		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		String reqUser1 = "{\"userName\": \"Tom\", \"password\":\"password1\"}";
		
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser1));
		
		mockMvc.perform(post("/api/user/"))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.data[0].userName").value("Frodo"))
			.andExpect(jsonPath("$.data[1].userName").value("Tom"));
	}
	

	@Test
	public void successDeleteUser() throws Exception {

		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		mockMvc.perform(post("/api/user/delete").param("userName", "Frodo"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.msg").value("Success"));
	}

	//Fail to delete if user does not exists
	@Test
	public void failDeleteUser() throws Exception {

		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		mockMvc.perform(post("/api/user/delete").param("userName", "UserFail"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.msg").value("Error"));
	}

	@Test
	public void successCreateRole() throws Exception {

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.data.roleName").value("role1"));
	}

	// Fail to create if role already exists 
	@Test
	public void failCreateRole() throws Exception {

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));
		
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.msg").value("Error"));
	}
	
	@Test
	public void retrieveRoleList() throws Exception {

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		String reqRole1 = "{\"roleName\": \"test2\", \"roleDesc\":\"test 2\"}";
		
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole1));
		
		mockMvc.perform(post("/api/role/"))
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.data[0].roleName").value("role1"))
			.andExpect(jsonPath("$.data[1].roleName").value("test2"));
	}
	
	@Test
	public void successDeleteRole() throws Exception {

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		mockMvc.perform(post("/api/role/delete").param("roleName", "role1"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.msg").value("Success"));
	}

	// Fail to delete if role does not exists 
	@Test
	public void failDeleteRole() throws Exception {

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		mockMvc.perform(post("/api/role/delete").param("roleName", "RoleFail"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.msg").value("Error"));
	}
	
	@Test
	public void successAddUsertoRole() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.data.roleName").value("role1"))
				.andExpect(jsonPath("$.data.userList[0].userName").value("Frodo"));
	}

	@Test
	public void successAddUsertoRole_1() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.data.userList.length()").value(1));
		
		//If the role is already associated with the user, nothing happen
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));
	}

	@Test
	public void failAddUsertoRole() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role2\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.msg").value("Error"));
	}
	
	@Test
	public void successRemoveUserfromRole() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		mockMvc.perform(post("/api/role/removeUserfromRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(0));	

	}
	
	//user does not exist
	@Test
	public void failRemoveUserfromRole() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		String reqUserRole1 = "{\"userName\": \"Tom\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/removeUserfromRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole1))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"));	

	}

	//Role does not exist
	@Test
	public void failRemoveUserfromRole_1() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		String reqUserRole1 = "{\"userName\": \"Frodo\", \"roleName\":\"role2\"}";
		mockMvc.perform(post("/api/role/removeUserfromRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole1))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"));	
	}

	//Role is not including user
	@Test
	public void failRemoveUserfromRole_2() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqUser1 = "{\"userName\": \"Tom\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser1));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		String reqUserRole1 = "{\"userName\": \"Tome\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/removeUserfromRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole1))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"));	

	}

	@Test
	public void succcessAuthenticate() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data.userName").value("Frodo"))
		.andExpect(jsonPath("$.data.roleList[0]").value("role1"))
		.andExpect(jsonPath("$.data.expiredDate").exists())
		.andExpect(jsonPath("$.data.token").exists());

	}

	//token already exists, only renew the expiriedDate
	@Test
	public void succcessAuthenticate_1() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data.userName").value("Frodo"))
		.andExpect(jsonPath("$.data.roleList[0]").value("role1"))
		.andExpect(jsonPath("$.data.expiredDate").exists())
		.andExpect(jsonPath("$.data.token").exists());

		mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data.userName").value("Frodo"))
		.andExpect(jsonPath("$.data.roleList[0]").value("role1"))
		.andExpect(jsonPath("$.data.expiredDate").exists())
		.andExpect(jsonPath("$.data.token").exists());
	}
	
	//Test token expired 
	@Test
	public void testTokenExpired() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		//Set token expired time is 2 seconds
		String result = mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser).param("expire", "2"))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();		
		JSONObject jsonObj = new JSONObject(result);
		String token = jsonObj.getJSONObject("data").getString("token");

		//before expired, can perform checkRole
		mockMvc.perform(post("/api/userToken/checkRole").param("token", token).param("roleName", "role1"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data").value("true"));
		
		Thread.sleep(2100);
		
		//before expired, throw token is invalid exception when perform checkRole
		mockMvc.perform(post("/api/userToken/checkRole").param("token", token).param("roleName", "role1"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"))
		.andExpect(jsonPath("$.data").value("Token is invalid."));
	}

	//Fail to authenticate if userName is not correct
	@Test
	public void failAuthenticate() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		String reqUser1 = "{\"userName\": \"Tom\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser1))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"));

	}
	
	//Fail to authenticate if password is not correct
	@Test
	public void failAuthenticate_1() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		String reqUser1 = "{\"userName\": \"Frodo\", \"password\":\"password1\"}";
		mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser1))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"));

	}

	@Test
	public void succcessInvalidate() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	

		String result = mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();		
		JSONObject jsonObj = new JSONObject(result);
		String token = jsonObj.getJSONObject("data").getString("token");
		
		mockMvc.perform(post("/api/userToken/invalidate").param("token", token))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"));
	}
	
	//Fail for invalid token
	@Test
	public void failInvalidate() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	

		mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser));
		
		String token = "bbbcbd3b-6ad7-4361-8785-e5af9a90069e";
		mockMvc.perform(post("/api/userToken/invalidate").param("token", token))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"))
		.andExpect(jsonPath("$.data").value("Token is invalid."));
	}


	@Test
	public void succcessCheckRole() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	

		String result = mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();		
		JSONObject jsonObj = new JSONObject(result);
		String token = jsonObj.getJSONObject("data").getString("token");
		
		mockMvc.perform(post("/api/userToken/checkRole").param("token", token).param("roleName", "role1"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data").value("true"));
	}
	
	//False for role is not matching
	@Test
	public void falseCheckRole() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqRole1 = "{\"roleName\": \"role2\", \"roleDesc\":\"role 2\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole1));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	

		String result = mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();		
		JSONObject jsonObj = new JSONObject(result);
		String token = jsonObj.getJSONObject("data").getString("token");
		
		mockMvc.perform(post("/api/userToken/checkRole").param("token", token).param("roleName", "role2"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data").value("false"));
	}

	//Fail for invalid token
	@Test
	public void failCheckRole() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	

		mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser));
		String token = "bbbcbd3b-6ad7-4361-8785-e5af9a90069e";
		
		mockMvc.perform(post("/api/userToken/checkRole").param("token", token).param("roleName", "role1"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"))
		.andExpect(jsonPath("$.data").value("Token is invalid."));
	}

	//Fail for role does not exist
	@Test
	public void failCheckRole_1() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	

		String result = mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();		
		JSONObject jsonObj = new JSONObject(result);
		String token = jsonObj.getJSONObject("data").getString("token");
		
		mockMvc.perform(post("/api/userToken/checkRole").param("token", token).param("roleName", "role2"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"))
		.andExpect(jsonPath("$.data").value("Role does not exist."));
	}

	@Test
	public void succcessretrieveAllRoles() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqRole1 = "{\"roleName\": \"role2\", \"roleDesc\":\"role 2\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole1));
		
		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	

		String reqUserRole1 = "{\"userName\": \"Frodo\", \"roleName\":\"role2\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole1))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		String result = mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();		
		JSONObject jsonObj = new JSONObject(result);
		String token = jsonObj.getJSONObject("data").getString("token");
		
		mockMvc.perform(post("/api/userToken/retrieveAllRoles").param("token", token))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data.[0]").value("role1"))
		.andExpect(jsonPath("$.data.[1]").value("role2"));
	}

	/*Test tokenMap's change when user and role mapping is changed,  user or role is deleted
	 *Logic:
	 *1. Create user Frodo
	 *2. Create role role1 and role2
	 *3. Add Frodo to role1
	 *4. Create authenticate
	 *5. Retrieve roles - only role1
	 *6. Add Frodo to role2
	 *7. Create role role3
	 *8. Add Frodo to role3
	 *9. Retrieve roles - there are role1, role2 and role3
	 *10. Remove Frodo from role1
	 *11. Retrieve roles - there are role2 and role3
	 *12. Delete role role2
	 *13. 11. Retrieve roles - only role3
	 *14. Delete user Frodo
	 *15. Error-Token is invalid because token was deleted either
	 *16. Check role list, there are role1 and role3, but userlist of both of them are blank
	 *
	 */
	@Test
	public void succcessretrieveAllRoles_1() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqRole1 = "{\"roleName\": \"role2\", \"roleDesc\":\"role 2\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole1));
		
		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole));	

		String result = mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();		
		JSONObject jsonObj = new JSONObject(result);
		String token = jsonObj.getJSONObject("data").getString("token");

		mockMvc.perform(post("/api/userToken/retrieveAllRoles").param("token", token))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data.[0]").value("role1"));
		
		String reqUserRole1 = "{\"userName\": \"Frodo\", \"roleName\":\"role2\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole1));	
		
		String reqRole2 = "{\"roleName\": \"role3\", \"roleDesc\":\"role 3\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole2));
		String reqUserRole2 = "{\"userName\": \"Frodo\", \"roleName\":\"role3\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole2));	

		mockMvc.perform(post("/api/userToken/retrieveAllRoles").param("token", token))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data.[0]").value("role1"))
		.andExpect(jsonPath("$.data.[1]").value("role2"))
		.andExpect(jsonPath("$.data.[2]").value("role3"));
		
		mockMvc.perform(post("/api/role/removeUserfromRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole));	

		mockMvc.perform(post("/api/userToken/retrieveAllRoles").param("token", token))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data.[0]").value("role2"))
		.andExpect(jsonPath("$.data.[1]").value("role3"));
		
		mockMvc.perform(post("/api/role/delete").param("roleName", "role2"));

		mockMvc.perform(post("/api/userToken/retrieveAllRoles").param("token", token))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data.[0]").value("role3"));

		mockMvc.perform(post("/api/user/delete").param("userName", "Frodo"));

		mockMvc.perform(post("/api/userToken/retrieveAllRoles").param("token", token))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"))
		.andExpect(jsonPath("$.data").value("Token is invalid."));

		mockMvc.perform(post("/api/role"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Success"))
		.andExpect(jsonPath("$.data.[0].roleName").value("role1"))
		.andExpect(jsonPath("$.data.[0].userList.length()").value(0))
		.andExpect(jsonPath("$.data.[1].roleName").value("role3"))
		.andExpect(jsonPath("$.data.[1].userList.length()").value(0));
		
	}	
	//Fail to retrieve because invalid token
	@Test
	public void failRetrieveAllRoles() throws Exception {
		String reqUser = "{\"userName\": \"Frodo\", \"password\":\"password\"}";
		mockMvc.perform(post("/api/user/create").contentType(MediaType.APPLICATION_JSON).content(reqUser));

		String reqRole = "{\"roleName\": \"role1\", \"roleDesc\":\"role 1\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole));

		String reqRole1 = "{\"roleName\": \"role2\", \"roleDesc\":\"role 2\"}";
		mockMvc.perform(post("/api/role/create").contentType(MediaType.APPLICATION_JSON).content(reqRole1));
		
		String reqUserRole = "{\"userName\": \"Frodo\", \"roleName\":\"role1\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	

		String reqUserRole1 = "{\"userName\": \"Frodo\", \"roleName\":\"role2\"}";
		mockMvc.perform(post("/api/role/addUsertoRole").contentType(MediaType.APPLICATION_JSON).content(reqUserRole1))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.data.userList.length()").value(1));	
		
		mockMvc.perform(post("/api/userToken/authenticate").contentType(MediaType.APPLICATION_JSON).content(reqUser));
		String token = "bbbcbd3b-6ad7-4361-8785-e5af9a90069e";
		
		mockMvc.perform(post("/api/userToken/retrieveAllRoles").param("token", token))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.msg").value("Error"))
		.andExpect(jsonPath("$.data").value("Token is invalid."));
	}	
	
}
